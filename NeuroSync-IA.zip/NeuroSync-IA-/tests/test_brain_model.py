from model.brain_model import simulate_brain

def test_simulation():
    assert simulate_brain() is None