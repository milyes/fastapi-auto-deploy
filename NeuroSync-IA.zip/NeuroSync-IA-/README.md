# NeuroSync-IA-
Un projet d’intelligence artificielle pour la synchronisation neuronale et la simulation de signaux cérébraux.

## Structure
- `model/` : Contient les modèles IA pour l’analyse ou la simulation cérébrale.
- `data/` : Données d'entrée ou d'exemple.
- `utils/` : Fonctions utilitaires.
- `main.py` : Point d’entrée principal.

## Exécution
```bash
pip install -r requirements.txt
python main.py
```