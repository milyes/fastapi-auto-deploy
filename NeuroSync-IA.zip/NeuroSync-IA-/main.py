from model.brain_model import simulate_brain
import json

if __name__ == "__main__":
    print("Lancement de NeuroSync-IA...")
    simulate_brain()