from flask import Flask, request
from onelogin.saml2.auth import OneLogin_Saml2_Auth
from onelogin.saml2.metadata import OneLogin_Saml2_Metadata
from onelogin.saml2.settings import OneLogin_Saml2_Settings

app = Flask(__name__)

def prepare_flask_request(request):
    return {
        'https': 'on',
        'http_host': request.host,
        'script_name': request.path,
        'server_port': request.environ.get('SERVER_PORT'),
        'get_data': request.args.copy(),
        'post_data': request.form.copy()
    }

@app.route("/metadata/")
def metadata():
    settings = OneLogin_Saml2_Settings(custom_base_path="saml")
    metadata, errors = OneLogin_Saml2_Metadata.builder(settings)
    return metadata, 200, {'Content-Type': 'text/xml'}

@app.route("/acs", methods=["POST"])
def acs():
    req = prepare_flask_request(request)
    auth = OneLogin_Saml2_Auth(req, custom_base_path="saml")
    auth.process_response()
    if not auth.get_errors():
        return f"Utilisateur connecté : {auth.get_nameid()}"
    return f"Erreur SAML : {auth.get_errors()}", 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
